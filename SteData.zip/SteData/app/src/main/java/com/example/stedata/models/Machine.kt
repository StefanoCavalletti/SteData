package com.example.stedata.models

data class Machine(
    val machineId: String = "",
    val lastUpdate: String = "",
    val totalRilevazioni: Int = 0
)